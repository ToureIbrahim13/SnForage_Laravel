
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header ">Liste des abonnements</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Identifiant</th>              
                            <th>Client </th>              
                            <th>Numero de compteur</th> 
                            <th>Date d'abonnement</th>                         
                            <th>Action</th>              
                            <th>Action</th>              
                        </tr>
                        @foreach($liste_abonnements as $abonnement)
                          <tr>
                              <td>{{ $abonnement->id }}</td>
                              <td>{{ $abonnement->client_id }}</td>
                              <td>{{ $abonnement->numero }}</td>
                              <td>{{ $abonnement->date }}</td>
                              <td><a href="{{ route('editabonnements', ['id'=>$abonnement->id]) }}">Editer</a></td>
                              <td><a href="{{ route('deleteabonnements', ['id'=>$abonnement->id]) }}" onclick="return confirm('voulez-vous supprimer ?');">Supprimer</a></td>         
                          </tr>
                          @endforeach
                    </table>
                    {{ $liste_abonnements->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 
