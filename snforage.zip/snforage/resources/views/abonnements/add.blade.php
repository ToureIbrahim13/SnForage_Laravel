@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des Abonnements</div>
                <div class="card-body">
                @if (isset($confirmation))
                     @if($confirmation ==1)
                <div class="alert alert-success">Abonnement ajouté</div>
                @else
                <div class="alert alert-danger">Abonnement non ajouté</div>
                  @endif
                @endif
             <form method="POST" action="{{ route('persistabonnements') }}">
                    @csrf
                    <div class="form-group">
                       <label class="control-label" for="client_id">Identifiant du Client</label>
                       <select class="form-control"  name="client_id" id="client_id">
                           <option value="0">Faites un choix</option>
                           @foreach($clients as $client)
                           <option value="{{ $client->id }}">{{ $client->nom}} {{ $client->prenom}}</option>
                            @endforeach
                        </select>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="numero">Numero du compteur</label>
                       <select class="form-control"  name="numero" id="numero">
                           <option value="0">Faites un choix</option>
                           @foreach($numero as $numero)
                           <option value="{{ $numero->id }}">{{ $numero->numero}}</option>
                            @endforeach
                        </select>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="date">Date d'abonnement</label>
                       <input class="form-control" type="date" name="date" id="date"/>
                   </div>
                   <div class="form-group">
                       <input class="btn btn-success"  type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
                       <input class="btn btn-danger"  type="reset" name="annuler" id="annuler" value="Annuler"/>
                   </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
@endsection
