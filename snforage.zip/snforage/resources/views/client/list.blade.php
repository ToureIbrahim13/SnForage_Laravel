
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header ">Liste des clients</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Identifiant</th>              
                            <th>Nom </th>              
                            <th>Prenom</th> 
                            <th>Adresse</th>              
                            <th>Telephone </th> 
                            <th>Village </th>              
                            <th>Chef village</th>              
                            <th>Action</th>              
                            <th>Action</th>              
                        </tr>
                        @foreach($liste_clients as $client)
                          <tr>
                              <td>{{ $client->id }}</td>
                              <td>{{ $client->nom }}</td>
                              <td>{{ $client->prenom }}</td>
                              <td>{{ $client->adresse }}</td>
                              <td>{{ $client->telephone }}</td>
                              <td>{{ $client->village }}</td>
                              <td>{{ $client->chef_village}}</td>
                              <td><a href="{{ route('editclient', ['id'=>$client->id]) }}">Editer</a></td>
                              <td><a href="{{ route('deleteclient', ['id'=>$client->id]) }}" onclick="return confirm('voulez-vous supprimer ?');">Supprimer</a></td>         
                          </tr>
                          @endforeach
                    </table>
                    {{ $liste_clients->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 
