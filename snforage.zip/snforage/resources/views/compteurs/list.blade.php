
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header ">Liste des clients</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Identifiant</th>              
                            <th>Etat </th>              
                            <th>Type</th> 
                            <th>Numero</th>                          
                            <th>Action</th>              
                            <th>Action</th>              
                        </tr>
                        @foreach($liste_compteurs as $compteur)
                          <tr>
                              <td>{{ $compteur->id }}</td>
                              <td>{{ $compteur->etat_id }}</td>
                              <td>{{ $compteur->type }}</td>
                              <td>{{ $compteur->numero }}</td>
                              <td><a href="{{ route('editcompteurs', ['id'=>$compteur->id]) }}">Editer</a></td>
                              <td><a href="{{ route('deletecompteurs', ['id'=>$compteur->id]) }}" onclick="return confirm('voulez-vous supprimer ?');">Supprimer</a></td>         
                          </tr>
                          @endforeach
                    </table>
                    {{ $liste_compteurs->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 
