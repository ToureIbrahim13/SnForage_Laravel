<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des clients</div>
                <div class="card-body">
                <?php if(isset($confirmation)): ?>
                     <?php if($confirmation ==1): ?>
                <div class="alert alert-success">Client ajouté</div>
                <?php else: ?>
                <div class="alert alert-danger">Client non ajouté</div>
                  <?php endif; ?>
                <?php endif; ?>
             <form method="POST" action="<?php echo e(route('updateclient')); ?>">
                    <?php echo csrf_field(); ?>
                   <div class="form-group">
                       <label class="control-label" for="id">Identifiant du client</label>
                       <input class="form-control" readonly="true" type="text" name="id" id="id" value="<?php echo e($client->id); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="nom">Nom du client</label>
                       <input class="form-control" type="text" name="nom" id="nom" value="<?php echo e($client->nom); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="prenom">Prenom du client</label>
                       <input class="form-control" type="text" name="prenom" id="prenom" value="<?php echo e($client->prenom); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="prenom">Adresse du client</label>
                       <input class="form-control" type="text" name="adresse" id="adresse" value="<?php echo e($client->adresse); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="telephone">Telephone du medecin</label>
                       <input class="form-control" type="text" name="telephone" id="telephone" value="<?php echo e($client->telephone); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="prenom">Village du client</label>
                       <input class="form-control" type="text" name="village" id="village" value="<?php echo e($client->village); ?>"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="prenom">Chef de village du client</label>
                       <input class="form-control" type="text" name="chef_village" id="chef_village" value="<?php echo e($client->chef_village); ?>"/>
                   </div>
                   <div class="form-group">
                       <input class="btn btn-success"  type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
                       <a class="btn btn-danger" href="<?php echo e(route('getallclient')); ?>">Annuler</a>
                   </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/client/edit.blade.php ENDPATH**/ ?>