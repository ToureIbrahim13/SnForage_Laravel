<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header ">Liste des clients</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Identifiant</th>              
                            <th>Etat </th>              
                            <th>Type</th> 
                            <th>Numero</th>                          
                            <th>Action</th>              
                            <th>Action</th>              
                        </tr>
                        <?php $__currentLoopData = $liste_compteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($compteur->id); ?></td>
                              <td><?php echo e($compteur->etat_id); ?></td>
                              <td><?php echo e($compteur->type); ?></td>
                              <td><?php echo e($compteur->numero); ?></td>
                              <td><a href="<?php echo e(route('editcompteurs', ['id'=>$compteur->id])); ?>">Editer</a></td>
                              <td><a href="<?php echo e(route('deletecompteurs', ['id'=>$compteur->id])); ?>" onclick="return confirm('voulez-vous supprimer ?');">Supprimer</a></td>         
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($liste_compteurs->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/compteurs/list.blade.php ENDPATH**/ ?>