<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card ">
                <div class="card-headers">Formulaire d'enregistrement des clients</div>
                <div class="card-body ">
                <?php if(isset($confirmation)): ?>
                     <?php if($confirmation ==1): ?>
                <div class="alert alert-success">Client ajouté</div>
                <?php else: ?>
                <div class="alert alert-danger">Client non ajouté</div>
                  <?php endif; ?>
                <?php endif; ?>
             <form method="POST" action="<?php echo e(route('persistclient')); ?>">
                    <?php echo csrf_field(); ?>
                   <div class="form-group">
                       <label class="control-label" for="nom">Nom du client</label>
                       <input class="form-control" type="text" name="nom" id="nom"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="prenom">Prenom du client</label>
                       <input class="form-control" type="text" name="prenom" id="prenom"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="telephone">Adresse du client</label>
                       <input class="form-control" type="text" name="adresse" id="adresse"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="telephone">Telephone du client</label>
                       <input class="form-control" type="text" name="telephone" id="telephone"/>
                   </div>
                   <div class="form-group"> 
                       <label class="control-label" for="telephone">Village du client</label>
                       <input class="form-control" type="text" name="village" id="village"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="telephone">Chef de village du client</label>
                       <input class="form-control" type="text" name="chef_village" id="chef_village"/>
                   </div>
                   <div class="form-group">
                       <input class="btn btn-success"  type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
                       <input class="btn btn-danger"  type="reset" name="annuler" id="annuler" value="Annuler"/>
                   </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/client/add.blade.php ENDPATH**/ ?>