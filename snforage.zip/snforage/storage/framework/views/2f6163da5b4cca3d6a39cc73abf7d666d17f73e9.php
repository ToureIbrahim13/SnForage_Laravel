<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des Compteurs</div>
                <div class="card-body">
                <?php if(isset($confirmation)): ?>
                     <?php if($confirmation ==1): ?>
                <div class="alert alert-success">compteur ajouté</div>
                <?php else: ?>
                <div class="alert alert-danger">compteur non ajouté</div>
                  <?php endif; ?>
                <?php endif; ?>
             <form method="POST" action="<?php echo e(route('persistcompteurs')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                       <label class="control-label" for="etat_id">Etat du Compteur</label>
                       <select class="form-control"  name="etat_id" id="etat_id">
                           <option value="0">Faites un choix</option>
                           <?php $__currentLoopData = $etats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($etat->id); ?>"><?php echo e($etat->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="type">Type de Compteur</label>
                       <input class="form-control" type="text" name="type" id="type"/>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="numero">Numero Compteur</label>
                       <input class="form-control" type="text" name="numero" id="numero"/>
                   </div>
                   
                   <div class="form-group">
                       <input class="btn btn-success"  type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
                       <input class="btn btn-danger"  type="reset" name="annuler" id="annuler" value="Annuler"/>
                   </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/compteurs/add.blade.php ENDPATH**/ ?>