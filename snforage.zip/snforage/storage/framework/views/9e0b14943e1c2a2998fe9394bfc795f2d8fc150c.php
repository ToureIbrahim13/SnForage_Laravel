<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des Abonnements</div>
                <div class="card-body">
                <?php if(isset($confirmation)): ?>
                     <?php if($confirmation ==1): ?>
                <div class="alert alert-success">Abonnement ajouté</div>
                <?php else: ?>
                <div class="alert alert-danger">Abonnement non ajouté</div>
                  <?php endif; ?>
                <?php endif; ?>
             <form method="POST" action="<?php echo e(route('persistabonnements')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                       <label class="control-label" for="client_id">Identifiant du Client</label>
                       <select class="form-control"  name="client_id" id="client_id">
                           <option value="0">Faites un choix</option>
                           <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom); ?> <?php echo e($client->prenom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="numero">Numero du compteur</label>
                       <select class="form-control"  name="numero" id="numero">
                           <option value="0">Faites un choix</option>
                           <?php $__currentLoopData = $numero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($numero->id); ?>"><?php echo e($numero->numero); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   </div>
                   <div class="form-group">
                       <label class="control-label" for="date">Date d'abonnement</label>
                       <input class="form-control" type="date" name="date" id="date"/>
                   </div>
                   <div class="form-group">
                       <input class="btn btn-success"  type="submit" name="envoyer" id="envoyer" value="Envoyer"/>
                       <input class="btn btn-danger"  type="reset" name="annuler" id="annuler" value="Annuler"/>
                   </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/abonnements/add.blade.php ENDPATH**/ ?>