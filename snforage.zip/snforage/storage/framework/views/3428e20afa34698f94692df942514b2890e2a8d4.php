<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header ">Liste des abonnements</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Identifiant</th>              
                            <th>Client </th>              
                            <th>Numero de compteur</th> 
                            <th>Date d'abonnement</th>                         
                            <th>Action</th>              
                            <th>Action</th>              
                        </tr>
                        <?php $__currentLoopData = $liste_abonnements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abonnement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($abonnement->id); ?></td>
                              <td><?php echo e($abonnement->client_id); ?></td>
                              <td><?php echo e($abonnement->numero); ?></td>
                              <td><?php echo e($abonnement->date); ?></td>
                              <td><a href="<?php echo e(route('editabonnements', ['id'=>$abonnement->id])); ?>">Editer</a></td>
                              <td><a href="<?php echo e(route('deleteabonnements', ['id'=>$abonnement->id])); ?>" onclick="return confirm('voulez-vous supprimer ?');">Supprimer</a></td>         
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($liste_abonnements->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\L3IAGE\projet\snforage\resources\views/abonnements/list.blade.php ENDPATH**/ ?>