<?php

namespace App\Http\Controllers;

use App\Etat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EtatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add()
    {
        return view('etat.add');
    }
    public function delete($id)
    {
        $etat =  Etat::find($id);
        if( $etat != null )
        {
            $etat->delete();
        }
        return $this->getAll();
    }
    public function persist(Request $request)
    {
        $etat = new Etat();
        $etat->nom = $request->nom;

        $result = $etat->save();//1 ou 0

        return view('etat.add', ['confirmation' => $result]);
    }
}
