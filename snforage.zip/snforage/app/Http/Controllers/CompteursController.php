<?php

namespace App\Http\Controllers;

use App\Etat;
use App\Compteurs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CompteursController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add()
    {
        $etats = Etat::all();
        return view('compteurs.add', ['etats' => $etats]);
    }
    public function getAll()
    {
        $liste_compteurs = Compteurs::paginate(2);
        return view('compteurs.list', ['liste_compteurs' => $liste_compteurs]);
    }
    public function edit($id)
    {
        $compteurs = Compteurs::find($id);
        return view('compteurs.edit', ['compteurs' => $compteurs]);
    }
    public function update(Request $request)
    {
        $compteurs = Compteurs::find($request->id);
        $compteurs->user_id = Auth::id();
        $compteurs->etat_id = $request->etat_id ;
        $compteurs->type = $request->type;
        $compteurs->numero = $request->numero;

        $result = $compteurs->save();//1 ou 0

        return redirect('/compteurs/getAll');
    }
    public function delete($id)
    {
        $compteurs =  Compteurs::find($id);
        if( $compteurs != null )
        {
            $compteurs->delete();
        }
        return redirect('/compteurs/getAll');
    }
    public function persist(Request $request)
    {
        $compteurs = new Compteurs();
        $compteurs->user_id = Auth::id();
        $compteurs->etat_id = $request->etat_id;
        $compteurs->type = $request->type;
        $compteurs->numero = $request->numero;

        $result = $compteurs->save();//1 ou 0
        $etats = Etat::all();
        return view('compteurs.add', ['confirmation' => $result],['etats'=>$etats]);
    }
}
