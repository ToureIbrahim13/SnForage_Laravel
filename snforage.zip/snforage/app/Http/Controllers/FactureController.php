<?php

namespace App\Http\Controllers;

use App\Client;
use App\Abonnements;
use App\Facture;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FactureController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add()
    {
        $client = Client::all();
        $numero = Abonnements::all();
        return view('facture.add', ['client' => $client,
                                        'numero' => $numero]);
    }
    public function getAll()
    {
        $liste_factures = Facture::all();
        return view('facture.list', ['liste_factures' => $liste_factures]);
    }
    public function edit($id)
    {
        $factures = Facture::find($id);
        return view('facture.edit', ['factures' => $factures]);
    }
    public function update(Request $request)
    {
        $facture = Facture::find($request->id);
        $facture->client_id = $request->client_id;
        $facture->user_id = Auth::id();
        $facture->date = $request->date;
        $facture->numero_abonnement = $request->numero_abonnement;

        $result = $facture->save();//1 ou 0

        return redirect('/facture/getAll');
    }
    public function delete($id)
    {
        $facture =  Facture::find($id);
        if( $facture != null )
        {
            $facture->delete();
        }
        return redirect('/facture/getAll');
    }
    public function persist(Request $request)
    {
        $facture = new Abonnements();
        $facture->client_id = $request->client_id;
        $facture->user_id = Auth::id();
        $facture->date = $request->date;
        $facture->numero_abonnement = $request->numero_abonnement;


        $result = $facture->save();//1 ou 0

        return view('facture.add', ['confirmation' => $result]);
    }
}
