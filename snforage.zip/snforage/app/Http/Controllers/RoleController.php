<?php

namespace App\Http\Controllers;

use App\Etat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RoleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add()
    {
        return view('role.add');
    }
    public function delete($id)
    {
        $role =  Role::find($id);
        if( $role != null )
        {
            $role->delete();
        }
        return $this->getAll();
    }
    public function persist(Request $request)
    {
        $role = new Etat();
        $role->nom = $request->nom;

        $result = $role->save();//1 ou 0

        return view('role.add', ['confirmation' => $result]);
    }
}
