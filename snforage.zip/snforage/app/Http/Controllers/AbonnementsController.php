<?php

namespace App\Http\Controllers;

use App\Client;
use App\Compteurs;
use App\Abonnements;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AbonnementsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function add()
    {
        $clients = Client::all();
        $numero = Compteurs::all();
        return view('abonnements.add', ['clients' => $clients, 'numero' => $numero]);
    }
    public function getAll()
    {
        $liste_abonnements = Abonnements::paginate(2);
        return view('abonnements.list', ['liste_abonnements' => $liste_abonnements]);
    }
    public function edit($id)
    {
        $abonnements = Abonnements::find($id);
        return view('abonnements.edit', ['abonnements' => $abonnements]);
    }
    public function update(Request $request)
    {
        $abonnements = Abonnements::find($request->id);
        $abonnements->user_id = Auth::id();
        $abonnements->client_id = $request->client_id;
        $abonnements->numero = $request->numero;
        $abonnements->date = $request->date;

        $result = $abonnements->save();//1 ou 0

        return redirect('/abonnements/getAll');
    }
    public function delete($id)
    {
        $abonnements =  Abonnements::find($id);
        if( $abonnements != null )
        {
            $abonnements->delete();
        }
        return redirect('/abonnements/getAll');
    }
    public function persist(Request $request)
    {
        $abonnements = new Abonnements();
        $abonnements->user_id = Auth::id();
        $abonnements->client_id = $request->client_id;
        $abonnements->numero = $request->numero;
        $abonnements->date = $request->date;

        $result = $abonnements->save();//1 ou 0
        $clients = Client::all();
        $numero = Compteurs::all();
        return view('abonnements.add', ['confirmation' => $result, 'clients'=>$clients, 'numero'=>$numero]);
    }
}
