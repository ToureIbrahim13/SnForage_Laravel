<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Abonnements extends Model
{
    protected $fillable = array('user_id', 'client_id', 'numero', 'date');
    public static $rules = array('user_id'=>'required|bigInteger', 
                                    'client_id'=>'required|integer',
                                    'numero'=>'required|min:20',   
                                    'date'=>'required|min:3'                                                         
                                );
    public function clients()
    {
        return $this->belongsTo('App\Client');
    }
    public function users()
    {
        return $this->belongsTo('App\User');
    }

    public function compteurs()
    {
        return $this->belongsTo('App\Compteurs');
    }
    public function factures()
    {
        return $this->hasMany('App\Facture');
    }
}
