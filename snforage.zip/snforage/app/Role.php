<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = array('nom');
    public static $rules = array('nom'=>'required|min:2');
}
