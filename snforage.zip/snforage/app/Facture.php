<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Facture extends Model
{
    
    protected $fillable = array('user_id', 'client_id', 'date','numero_abonnement');
    public static $rules = array('client_id'=>'required|integer',
                                    'user_id'=>'required|bigInteger',
                                    'date'=>'required|min:3',
                                    'numero_abonnement'=>'required|bigInteger'                                                         
                                );
    public function clients()
    {
        return $this->belongsTo('App\Client');
    }
    public function users()
    {
        return $this->belongsTo('App\User');
    }
    public function abonnements()
    {
        return $this->belongsTo('App\Abonnements');
    }
}
