<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Etat extends Model
{
    protected $fillable = array('nom');
    public static $rules = array('nom'=>'required|min:2'                                 
                                );
    public function compteurs()
    {
        return $this->hasMany('App\Compteurs');
    }
}
