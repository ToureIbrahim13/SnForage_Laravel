<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compteurs extends Model
{
    protected $fillable = array('user_id','etat_id','type','numero');
    public static $rules = array('user_id'=>'required|bigInteger', 
                                     'etat_id'=>'required|integer', 
                                     'type'=>'required|min:20', 
                                     'numero'=>'required|min:20'                                 
                                );
    public function etats()
    {
        return $this->belongsTo('App\Etat');
    }
    public function users()
    {
        return $this->belongsTo('App\User');
    }
    public function abonnements()
    {
        return $this->hasMany('App\Abonnements');
    }
}
