<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/abonnements/add', 'AbonnementsController@add')->name('addabonnements');
Route::get('/abonnements/edit/{id}', 'AbonnementsController@edit')->name('editabonnements');
Route::post('/abonnements/update', 'AbonnementsController@update')->name('updateabonnements');
Route::get('/abonnements/delete/{id}', 'AbonnementsController@delete')->name('deleteabonnements');
Route::get('/abonnements/getAll', 'AbonnementsController@getAll')->name('getallabonnements');
Route::post('/abonnements/persist', 'AbonnementsController@persist')->name('persistabonnements');

Route::get('/client/add', 'ClientController@add')->name('addclient');
Route::get('/client/edit/{id}', 'ClientController@edit')->name('editclient');
Route::post('/client/update', 'ClientController@update')->name('updateclient');
Route::get('/client/delete/{id}', 'ClientController@delete')->name('deleteclient');
Route::get('/client/getAll', 'ClientController@getAll')->name('getallclient');
Route::post('/client/persist', 'ClientController@persist')->name('persistclient');

Route::get('/compteurs/add', 'CompteursController@add')->name('addcompteurs');
Route::get('/compteurs/edit/{id}', 'CompteursController@edit')->name('editcompteurs');
Route::post('/compteurs/update', 'CompteursController@update')->name('updatecompteurs');
Route::get('/compteurs/delete/{id}', 'CompteursController@delete')->name('deletecompteurs');
Route::get('/compteurs/getAll', 'CompteursController@getAll')->name('getallcompteurs');
Route::post('/compteurs/persist', 'CompteursController@persist')->name('persistcompteurs');

Route::get('/etat/add', 'EtatController@add')->name('addetat');
Route::get('/etat/delete/{id}', 'EtatController@delete')->name('deleteetat');
Route::post('/etat/persist', 'EtatController@persist')->name('persistetat');

Route::get('/role/add', 'RoleController@add')->name('addrole');
Route::get('/role/delete/{id}', 'RoleController@delete')->name('deleterole');
Route::post('/role/persist', 'RoleController@persist')->name('persistrole');

Route::get('/facture/add', 'FactureController@add')->name('addfacture');
Route::get('/facture/edit/{id}', 'FactureController@edit')->name('editfacture');
Route::post('/facture/update', 'FactureController@update')->name('updatefacture');
Route::get('/facture/delete/{id}', 'FactureController@delete')->name('deletefacture');
Route::get('/facture/getAll', 'FactureController@getAll')->name('getallfacture');
Route::post('/facture/persist', 'FactureController@persist')->name('persistfacture');